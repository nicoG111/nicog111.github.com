<?php

  /*
    ./noyau/init.php
    Initialisation de l'application
  */

    session_start();

    require_once '../app/config/parametres.php';
    require_once '../noyau/constantes.php';
    require_once '../noyau/connexion.php';
    require_once '../noyau/fonctions.php';
