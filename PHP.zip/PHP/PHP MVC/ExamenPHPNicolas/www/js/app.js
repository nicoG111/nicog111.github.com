$(function() {
	$('.delete').click(function() {

		if (!confirm('Etes-vous sûr de vouloir supprimer ce projet ?')) {
			return true;
		}
	});
});
