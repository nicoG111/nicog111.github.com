<?php

  /*
    ./www/index.php
  */

  require_once '../noyau/init.php';
  require_once '../app/routeur.php';
  require_once '../app/vues/template/index.php';
