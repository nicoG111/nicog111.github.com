<?php

  /*
    ./app/routeur.php
    Routeur principal
    Charge le contrôleur et lance l'action correspondant à ce qui se passe dans l'URL
  */


if (isset($_GET['projetId'])):
  // DETAIL D'UN PROJET
  // PATTERN: ?projetId=xxx
  // CTRL: projetsControleur
  // ACTION: show
include_once '../app/controleurs/projetsControleur.php';
\App\Controleurs\ProjetsControleur\showAction($connexion, $_GET['projetId']);

 elseif (isset($_GET['projets'])):
   include_once '../app/routeurs/projetsRouteur.php';

   elseif (isset($_GET['tags'])):
     include_once '../app/routeurs/tagsRouteur.php';


 elseif (isset($_GET['email'])):
   // AJOUT D'UN EMAIL
   // PATTERN: ?email=xxx
   // CTRL: abonnesControleur
   // ACTION: add
   include_once '../app/controleurs/abonnesControleur.php';
   \App\Controleurs\AbonnesControleur\addAction($connexion, $_GET['email']);

     elseif (isset($_GET['editForm'])):
     // EDITION  D'UN TAG: FORMULAIRE
     // PATTERN: ?editForm = xxx
     // CTRL: tagsControleur
     // ACTION: editForm
     include_once '../app/controleurs/tagsControleur.php';
     \App\Controleurs\TagsControleur\editFormAction($connexion, $_GET['editForm']);



else:
  // ROUT PAR DEFAUT
  // PATTERN: /
  // CTRL: projetsControleur
  // ACTION: index
include_once '../app/controleurs/projetsControleur.php';
\App\Controleurs\ProjetsControleur\indexAction($connexion);
endif;
