<?php

/*
./app/routeurs/projetsRouteur.php
*/

use \App\Controleurs\TagsControleur;

include_once '../app/controleurs/tagsControleur.php';


switch ($_GET['tags']):
  case 'edit':
  // EDITION D'UN TAGS: UPDATE
     // PATTERN: index.php?tags=edit&id=x
     // CTRL: tagsControleur
     // ACTION: edit
     TagsControleur\editAction($connexion, $_GET['id']);
    break;

  endswitch;
