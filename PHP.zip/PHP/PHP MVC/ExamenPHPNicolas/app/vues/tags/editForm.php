   <div class="row">
<div class="col-lg-8">
  <hr>
<h5 class="card-header">Modification Tag</h5>
<div class="card-body">
  <form class="" action="tags/<?php echo $tag['id']; ?>/<?php echo \Noyau\Fonctions\slugify($tag['nom']); ?>/edit/update.html" method="post">
    <div class="input-group">
      <input type="text" name="nom" id="nom" class="form-control" placeholder="<?php echo $tag['nom'] ?>">
      <span class="input-group-btn">
        <input class="btn btn-secondary" type="submit" value="Modifiez" />
      </span>
    </div>
  </form>
</div>
</div>
</div>
