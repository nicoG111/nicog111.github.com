        <ul class="list-unstyled mb-0">
<?php foreach ($tags as $tag): ?>
  <li>
    <a href="#"><?php echo $tag['nom'] ?></a> | <a href="?editForm=<?php echo $tag['id'] ?>">Modifier</a>
  </li>
<?php endforeach; ?>
        </ul>
