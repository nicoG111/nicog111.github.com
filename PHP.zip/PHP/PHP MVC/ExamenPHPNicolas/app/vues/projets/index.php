<?php
/*
./app/vues/projets/index.php
*/
?>
<h1 class="mt-4">Les projets <small>Design capill'Hair</small></h1>

<hr>


<?php foreach ($projets as $projet): ?>
  <div class="row">
    <div class="col-md-4">
      <a href="#">
        <img class="img-fluid rounded mb-3 mb-md-0" src="images/<?php echo $projet['projetImage'] ?>" alt="">
      </a>
    </div>
    <div class="col-md-8">
      <h3><?php echo $projet['titre'] ?></h3>
      <p class="lead">
        par
        <a href="artiste_details.html"><?php echo $projet['pseudo'] ?></a> le <?php echo Noyau\Fonctions\datify($projet['dateCreation'],'Y\-m\-d'); ?>
      </p>
      <p><?php echo mb_strimwidth($projet['texte'],0 , 100, "..."); ?></p>
      <a class="btn btn-primary" href="?projetId=<?php echo $projet['projetId'] ?>">View Project</a>
      <hr/>
      <ul class="list-inline tags">
        <li><a href="#" class="btn btn-default btn-xs">Vintage</a></li>
        <li><a href="#" class="btn btn-default btn-xs">Football</a></li>
      </ul>
    </div>
  </div>
  <!-- /.row -->

  <hr>
<?php endforeach; ?>
