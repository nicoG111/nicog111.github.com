<div class="row">

  <!-- Post Content Column -->
  <div class="col-lg-8">

    <!-- Page Heading -->

    <!-- Title -->
    <h1 class="mt-4">Newsletter</h1>

    <hr>


    <!-- Post Content -->
    <p class="lead">Merci, votre mail a bien été ajouté à notre base de données.</p>





  </div>
</div>
