<div class="container">

  <div class="row">

    <!-- Post Content Column -->
    <div class="col-lg-8">

      <!-- Page Heading -->

      <!-- Title -->
      

      <!-- Project One -->
      <?php echo $content; ?>




    </div>
