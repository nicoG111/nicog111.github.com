<!-- Search Widget -->

<div class="card my-4">
  <h5 class="card-header">Newsletter</h5>
  <div class="card-body">
    <form class="" action="form.php" method="get">
      <div class="input-group">
        <input type="email" name="email" class="form-control" placeholder="Votre mail">
        <span class="input-group-btn">
          <input class="btn btn-secondary" type="submit" value="Go!" />
        </span>
      </div>
    </form>

  </div>
</div>

<!-- Categories Widget -->
<div class="card my-4">
  <h5 class="card-header">Tags</h5>
  <div class="card-body">
    <div class="row">
      <div class="col-lg-12">


          <?php
            include_once '../app/controleurs/tagsControleur.php';
            \App\Controleurs\TagsControleur\indexAction($connexion)
           ?>

      </div>

    </div>
  </div>
</div>


</div>

</div>
