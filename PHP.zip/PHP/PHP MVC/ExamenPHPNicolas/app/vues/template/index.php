<!DOCTYPE html>
<html lang="en">

  <head>
    <?php include '../app/vues/template/partials/_head.php'; ?>
  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
          <?php include '../app/vues/template/partials/_nav.php'; ?>
    </nav>

    <!-- Page Content -->
              <?php include '../app/vues/template/partials/_main.php'; ?>
    

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4">
          <?php include '../app/vues/template/partials/_sidebar.php'; ?>

      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
                <?php include '../app/vues/template/partials/_footer.php'; ?>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
                    <?php include '../app/vues/template/partials/_script.php'; ?>


  </body>

</html>
