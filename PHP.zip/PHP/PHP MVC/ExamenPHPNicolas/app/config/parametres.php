<?php

  /*
    ./app/parametres.php
  */

    // PARAMETRES DE CONNEXION
    define('HOSTNAME', 'localhost');
    define('DBNAME', 'creatifs');
    define('USERNAME', 'root');
    define('USERPWD', '');
    // INITIALISATION DES ZONES DYNAMIQUES
    $title   = '';
    $content = '';
