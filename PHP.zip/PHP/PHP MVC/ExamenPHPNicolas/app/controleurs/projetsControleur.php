<?php

/*
./app/controleurs/projetsControleur.php
*/

namespace App\Controleurs\ProjetsControleur;
use App\Modeles\ProjetsModele;

function indexAction(\PDO $connexion){
  //Je mets dans $projets la liste des 10 derniers projets que je demande au modèle
  include_once '../app/modeles/projetsModele.php';
  $projets = ProjetsModele\findAll($connexion);
  //Je charge la vue projet/index dans $content
  GLOBAL $content, $title;
  $title = "CREA'TIFs - Design capill'Hair";
  ob_start();
  include '../app/vues/projets/index.php';
  $content = ob_get_clean();
}

function showAction(\PDO $connexion, int $id) {
    // Je mets dans $projets les infos du projet que je demande au modèle
    include_once '../app/modeles/projetsModele.php';
    $projet = ProjetsModele\findOneById($connexion, $id);
    // Je charge la vue show dans $content
    GLOBAL $content, $title;
    $title = $projet['titre'];
    ob_start();
    include '../app/vues/projets/show.php';
    $content = ob_get_clean();
 }


 function deleteAction(\PDO $connexion, int $id) {

   //Je demande au modèle de supprimer les liaison N-M correspondantes
        include_once '../app/modeles/projetsModele.php';
    $return1 = ProjetsModele\deleteProjetsHasTagsByPojetId($connexion, $id);
    // Je demande au modele de delete le projet

    $return2 = ProjetsModele\deleteOneById($connexion, $id);
    // Renvoi à la liste des projets
    header('location: ' . BASE_URL);
 }
