<?php

/*
./app/controleurs/abonnesControleur.php
*/
namespace App\Controleurs\AbonnesControleur;
use App\Modeles\AbonnesModele;

function addAction(\PDO $connexion) {
    // Je mets dans $projets les infos du projet que je demande au modèle
    include_once '../app/modeles/abonnesModele.php';
    $abonne = AbonnesModele\insert($connexion, $_GET['email']);
    // Je charge la vue add dans $content
    GLOBAL $content, $title;
    $title = "Ajout d'un abonné";
    ob_start();
    include '../app/vues/abonnes/add.php';
    $content = ob_get_clean();
 }
