<?php

  /*
    ./app/controleurs/tagsControleur.php
  */

    namespace App\Controleurs\TagsControleur;
    use App\Modeles\TagsModele;

    function indexAction(\PDO $connexion){

      // Je mets dans $tags la liste des tags que je demande au modèle
      include_once '../app/modeles/tagsModele.php';
      $tags = TagsModele\findAll($connexion);
      // Je charge directement la vue index
        include '../app/vues/tags/index.php';
    }

    function editFormAction(\PDO $connexion, int $id) {
        // Je mets dans $projets les infos du projet que je demande au modèle
        include_once '../app/modeles/tagsModele.php';
        $tag = TagsModele\findOneById($connexion, $id);
        // Je charge la vue editForm dans $content
        GLOBAL $content, $title;
        $title = "Modification d'un tag";
        ob_start();
        include '../app/vues/tags/editForm.php';
        $content = ob_get_clean();
     }


    function editAction(\PDO $connexion, int $id){
      //Je demande au modèle d'updater le tag
      include_once '../app/modeles/tagsModele.php';
      $return = TagsModele\updateOneById($connexion, $id, $_POST);

          header('location: ' . BASE_URL);

    }
