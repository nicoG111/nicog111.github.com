<?php

  /*
    ./app/modeles/categoriesModele.php
  */

  namespace App\Modeles\TagsModele;



    function findAll(\PDO $connexion) {
      $sql = "SELECT *
              FROM tags
              ORDER BY nom ASC;";
      $rs = $connexion->query($sql);
      return $rs->fetchAll(\PDO::FETCH_ASSOC);
    }

    function findOneById(\PDO $connexion, int $id) {
       $sql = "SELECT *
               FROM tags
               WHERE id = :id;";
       $rs = $connexion->prepare($sql);
       $rs->bindValue(':id', $id, \PDO::PARAM_INT);
       $rs->execute();
       return $rs->fetch(\PDO::FETCH_ASSOC);
    }

    function updateOneById(\PDO $connexion, int $id, array $data) :bool  {
       $sql = "UPDATE tags
               SET nom = :nom
               WHERE id = :id;";
       $rs = $connexion->prepare($sql);
       $rs->bindValue(':nom', $data['nom'], \PDO::PARAM_STR);
       $rs->bindValue(':id', $id, \PDO::PARAM_INT);
       return intval($rs->execute());
    }
