<?php
/*
/app/modeles/projetsModele.php
*/

namespace App\Modeles\AbonnesModele;

Function insert(\PDO $connexion, $data){
  $sql = "INSERT INTO abonnes
          SET mail = :mail;";
          $rs = $connexion->prepare($sql);
          $rs->bindValue(':mail', $_GET['email'], \PDO::PARAM_STR);
          $rs->execute();
          return $rs;
}
