<?php
/*
/app/modeles/projetsModele.php
*/

namespace App\Modeles\ProjetsModele;

function findAll(\PDO $connexion){
  $sql = "SELECT *,
          p.id AS projetId,
          c.id AS creatifId,
          c.image AS creatifImage,
          p.image AS projetImage
          FROM projets p
          JOIN creatifs c ON p.creatif = c.id
          ORDER BY p.dateCreation DESC
          LIMIT 10;";
  $rs = $connexion->query($sql);
  return $rs->fetchAll(\PDO::FETCH_ASSOC);
}

function findOneById(\PDO $connexion, int $id) {
   $sql = "SELECT *,
           p.id AS projetId,
           c.id AS creatifId,
           c.image AS creatifImage,
           p.image AS projetImage
           FROM projets p
           JOIN creatifs c ON p.creatif = c.id
           WHERE p.id = :id;";
   $rs = $connexion->prepare($sql);
   $rs->bindValue(':id', $id, \PDO::PARAM_INT);
   $rs->execute();
   return $rs->fetch(\PDO::FETCH_ASSOC);
}
function deleteProjetsHasTagsByPojetId(\PDO $connexion, int $projetId){
  $sql = "DELETE FROM projet_has_tags
          WHERE projet = :projet;";
  $rs = $connexion->prepare($sql);
  $rs->bindValue(':projet', $projetId, \PDO::PARAM_INT);
   return $rs->execute();
}

function deleteOneById(\PDO $connexion, int $id)  {
   $sql = "DELETE FROM projets
           WHERE id = :id;";
  $rs = $connexion->prepare($sql);
   $rs->bindValue(':id', $id, \PDO::PARAM_INT);
   return $rs->execute();

}
